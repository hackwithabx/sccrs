module.exports=[80922,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_owasp_page_actions_3365442c.js.map