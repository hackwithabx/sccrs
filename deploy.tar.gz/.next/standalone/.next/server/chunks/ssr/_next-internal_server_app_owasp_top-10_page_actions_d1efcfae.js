module.exports=[6601,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_owasp_top-10_page_actions_d1efcfae.js.map