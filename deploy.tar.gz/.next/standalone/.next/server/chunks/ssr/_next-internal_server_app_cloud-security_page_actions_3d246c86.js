module.exports=[80555,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cloud-security_page_actions_3d246c86.js.map