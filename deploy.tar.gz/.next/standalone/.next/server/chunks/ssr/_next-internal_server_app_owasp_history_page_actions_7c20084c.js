module.exports=[97796,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_owasp_history_page_actions_7c20084c.js.map