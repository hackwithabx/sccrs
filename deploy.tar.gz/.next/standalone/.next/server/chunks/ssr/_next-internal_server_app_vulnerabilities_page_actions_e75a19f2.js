module.exports=[59028,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_vulnerabilities_page_actions_e75a19f2.js.map