module.exports=[46927,a=>{"use strict";function b({children:a}){return a}a.s(["default",()=>b,"metadata",0,{title:"Dashboard | SecureCodeReviews",description:"Your SecureCodeReviews dashboard — access security tools, reports, recent assessments, and resources."}])}];

//# sourceMappingURL=app_dashboard_layout_tsx_637e6e08._.js.map