module.exports=[20842,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_owasp_top-10-2025_page_actions_69fdf15d.js.map