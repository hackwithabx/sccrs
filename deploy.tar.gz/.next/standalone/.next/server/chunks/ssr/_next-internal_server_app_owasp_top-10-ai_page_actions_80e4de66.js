module.exports=[44321,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_owasp_top-10-ai_page_actions_80e4de66.js.map