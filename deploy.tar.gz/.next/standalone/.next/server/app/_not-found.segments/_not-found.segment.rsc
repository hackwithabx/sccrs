1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/b70c2acfe835be27.js","/_next/static/chunks/a2dfb6fc5208ab9b.js","/_next/static/chunks/2b42d137df528a13.js","/_next/static/chunks/59d073c7584e9bee.js"],"default"]
3:I[37457,["/_next/static/chunks/b70c2acfe835be27.js","/_next/static/chunks/a2dfb6fc5208ab9b.js","/_next/static/chunks/2b42d137df528a13.js","/_next/static/chunks/59d073c7584e9bee.js"],"default"]
0:{"buildId":"mdp0O21V9GZuLXDhqLpuN","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
